// Keys in the schema:
export const schemaKeys = {
  showButton: "show-button",
  tesseractLanguages: "tesseract-languages",
  textgrabberShortcut: "textgrabber-shortcut",
};
