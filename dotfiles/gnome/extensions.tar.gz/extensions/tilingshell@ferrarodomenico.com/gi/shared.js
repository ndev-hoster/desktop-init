import Gio from "gi://Gio";
import GLib from "gi://GLib";
import GObject from "gi://GObject";
export {
  GLib,
  GObject,
  Gio
};
