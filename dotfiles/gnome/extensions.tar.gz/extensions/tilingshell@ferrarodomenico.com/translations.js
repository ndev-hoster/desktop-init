import { gettext as _, ngettext, pgettext } from "resource:///org/gnome/shell/extensions/extension.js";
export {
  _,
  ngettext,
  pgettext
};
